import { useState } from 'react';
import {
  Paper,
  Card,
  CardContent,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  Lock,
  LockOpen,
  Schedule,
} from '@mui/icons-material';

interface FrequencyPageProps {
  userRole: 'intern' | 'supervisor';
}

interface TimeRecord {
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  locked: boolean;
  approved: boolean;
}

export function FrequencyPage({ userRole }: FrequencyPageProps) {
  const [records, setRecords] = useState<TimeRecord[]>([
    {
      date: '2026-05-28',
      checkIn: '09:00',
      checkOut: '18:00',
      locked: true,
      approved: true,
    },
    {
      date: '2026-05-27',
      checkIn: '08:30',
      checkOut: '17:30',
      locked: true,
      approved: true,
    },
  ]);

  const [currentCheckIn, setCurrentCheckIn] = useState<string | null>(null);
  const [unlockDialogOpen, setUnlockDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<number | null>(null);
  const [unlockReason, setUnlockReason] = useState('');

  const today = new Date().toISOString().split('T')[0];
  const todayRecord = records.find((r) => r.date === today);

  const handleCheckIn = () => {
    const now = new Date().toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
    setCurrentCheckIn(now);

    const newRecord: TimeRecord = {
      date: today,
      checkIn: now,
      checkOut: null,
      locked: false,
      approved: false,
    };

    setRecords((prev) => [newRecord, ...prev.filter((r) => r.date !== today)]);
  };

  const handleCheckOut = () => {
    const now = new Date().toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });

    setRecords((prev) =>
      prev.map((r) =>
        r.date === today ? { ...r, checkOut: now, locked: true } : r
      )
    );
    setCurrentCheckIn(null);
  };

  const handleUnlockRequest = (index: number) => {
    setSelectedRecord(index);
    setUnlockDialogOpen(true);
  };

  const handleUnlock = () => {
    if (selectedRecord !== null) {
      setRecords((prev) =>
        prev.map((r, i) =>
          i === selectedRecord ? { ...r, locked: false } : r
        )
      );
      setUnlockDialogOpen(false);
      setUnlockReason('');
      setSelectedRecord(null);
    }
  };

  const handleTimeChange = (index: number, field: 'checkIn' | 'checkOut', value: string) => {
    setRecords((prev) =>
      prev.map((r, i) => (i === index ? { ...r, [field]: value } : r))
    );
  };

  const calculateWorkHours = (checkIn: string | null, checkOut: string | null) => {
    if (!checkIn || !checkOut) return '0h 00min';

    const [inH, inM] = checkIn.split(':').map(Number);
    const [outH, outM] = checkOut.split(':').map(Number);

    const totalMinutes = outH * 60 + outM - (inH * 60 + inM);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;

    return `${hours}h ${minutes.toString().padStart(2, '0')}min`;
  };

  return (
    <div className="space-y-6">
      <Card elevation={3}>
        <CardContent>
          <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Schedule /> Registro de Ponto - Hoje
          </h2>

          {!currentCheckIn && !todayRecord ? (
            <div className="text-center py-8">
              <p className="text-gray-600 mb-4">Você ainda não registrou entrada hoje</p>
              <Button
                variant="contained"
                size="large"
                startIcon={<PlayArrow />}
                onClick={handleCheckIn}
                sx={{ px: 6, py: 2 }}
              >
                Registrar Entrada
              </Button>
            </div>
          ) : currentCheckIn ? (
            <div className="text-center py-8">
              <div className="mb-4">
                <Chip
                  label={`Entrada: ${currentCheckIn}`}
                  color="success"
                  size="large"
                  sx={{ fontSize: '1.1rem', py: 3, px: 2 }}
                />
              </div>
              <p className="text-gray-600 mb-4">Você está trabalhando</p>
              <Button
                variant="contained"
                color="error"
                size="large"
                startIcon={<Stop />}
                onClick={handleCheckOut}
                sx={{ px: 6, py: 2 }}
              >
                Registrar Saída
              </Button>
            </div>
          ) : (
            <div className="text-center py-8">
              <Alert severity="success" sx={{ mb: 3 }}>
                Ponto registrado com sucesso!
              </Alert>
              <div className="space-y-2">
                <Chip
                  label={`Entrada: ${todayRecord?.checkIn}`}
                  color="success"
                  size="large"
                />
                <Chip
                  label={`Saída: ${todayRecord?.checkOut}`}
                  color="error"
                  size="large"
                />
                <div className="mt-3">
                  <p className="text-lg font-semibold text-gray-700">
                    Total: {calculateWorkHours(todayRecord?.checkIn || null, todayRecord?.checkOut || null)}
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Paper elevation={3} className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Histórico de Registros</h3>

        <div className="space-y-3">
          {records.map((record, index) => (
            <Card key={index} variant="outlined">
              <CardContent>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-700 mb-2">
                      {new Date(record.date + 'T12:00:00').toLocaleDateString('pt-BR', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </p>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm text-gray-600 block mb-1">Entrada</label>
                        <TextField
                          type="time"
                          size="small"
                          value={record.checkIn || ''}
                          onChange={(e) => handleTimeChange(index, 'checkIn', e.target.value)}
                          disabled={record.locked}
                          sx={{ width: '100%' }}
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-600 block mb-1">Saída</label>
                        <TextField
                          type="time"
                          size="small"
                          value={record.checkOut || ''}
                          onChange={(e) => handleTimeChange(index, 'checkOut', e.target.value)}
                          disabled={record.locked}
                          sx={{ width: '100%' }}
                        />
                      </div>
                    </div>

                    <p className="text-sm text-gray-600 mt-2">
                      Total: {calculateWorkHours(record.checkIn, record.checkOut)}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2 items-end">
                    {record.approved && (
                      <Chip label="Aprovado" color="success" size="small" />
                    )}
                    {record.locked ? (
                      <Chip
                        icon={<Lock />}
                        label="Bloqueado"
                        color="default"
                        size="small"
                      />
                    ) : (
                      <Chip
                        icon={<LockOpen />}
                        label="Desbloqueado"
                        color="warning"
                        size="small"
                      />
                    )}

                    {record.locked && userRole === 'intern' && (
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => handleUnlockRequest(index)}
                      >
                        Solicitar Desbloqueio
                      </Button>
                    )}

                    {record.locked && userRole === 'supervisor' && (
                      <Button
                        size="small"
                        variant="contained"
                        color="warning"
                        startIcon={<LockOpen />}
                        onClick={() => {
                          setRecords((prev) =>
                            prev.map((r, i) =>
                              i === index ? { ...r, locked: false } : r
                            )
                          );
                        }}
                      >
                        Desbloquear
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </Paper>

      <Dialog open={unlockDialogOpen} onClose={() => setUnlockDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Solicitar Desbloqueio de Horário</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 3 }}>
            Esta solicitação será enviada ao supervisor para aprovação.
          </Alert>
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Motivo do desbloqueio"
            value={unlockReason}
            onChange={(e) => setUnlockReason(e.target.value)}
            placeholder="Ex: Esqueci de registrar a saída, preciso corrigir o horário..."
            required
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUnlockDialogOpen(false)}>Cancelar</Button>
          <Button
            variant="contained"
            onClick={handleUnlock}
            disabled={!unlockReason.trim()}
          >
            Enviar Solicitação
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
