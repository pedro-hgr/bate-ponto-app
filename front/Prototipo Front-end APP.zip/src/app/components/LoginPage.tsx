import { useState } from 'react';
import { Paper, TextField, Button, Radio, RadioGroup, FormControlLabel, FormLabel } from '@mui/material';
import { Login as LoginIcon } from '@mui/icons-material';

interface LoginPageProps {
  onLogin: (user: { name: string; role: 'intern' | 'supervisor' }) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [name, setName] = useState('');
  const [role, setRole] = useState<'intern' | 'supervisor'>('intern');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onLogin({ name: name.trim(), role });
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-blue-700">
      <Paper elevation={8} className="p-8 max-w-md w-full mx-4">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
            <LoginIcon sx={{ fontSize: 32, color: '#1976d2' }} />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Bate Ponto</h1>
          <p className="text-gray-600 mt-2">Sistema de Controle de Frequência</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <TextField
            fullWidth
            label="Nome"
            variant="outlined"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            autoFocus
          />

          <div>
            <FormLabel component="legend" sx={{ mb: 1 }}>
              Tipo de Usuário
            </FormLabel>
            <RadioGroup
              value={role}
              onChange={(e) => setRole(e.target.value as 'intern' | 'supervisor')}
            >
              <FormControlLabel value="intern" control={<Radio />} label="Estagiário" />
              <FormControlLabel value="supervisor" control={<Radio />} label="Supervisor" />
            </RadioGroup>
          </div>

          <Button
            type="submit"
            fullWidth
            variant="contained"
            size="large"
            startIcon={<LoginIcon />}
            sx={{ mt: 3, py: 1.5 }}
          >
            Entrar
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Protótipo - Atividade Semestral</p>
          <p>Processos de Negócios - 2026.1</p>
        </div>
      </Paper>
    </div>
  );
}
